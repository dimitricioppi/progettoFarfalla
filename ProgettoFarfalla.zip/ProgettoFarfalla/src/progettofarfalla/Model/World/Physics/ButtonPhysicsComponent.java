/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package progettofarfalla.Model.World.Physics;

import progettofarfalla.Model.Game.GameObjects.GameObject;
import progettofarfalla.Model.World.World;

/**
 *
 * @author Daniela
 */
public class ButtonPhysicsComponent extends PhysicsComponent{
    
    @Override
    public void update(long dt, GameObject obj, World w) {          
    }
}
