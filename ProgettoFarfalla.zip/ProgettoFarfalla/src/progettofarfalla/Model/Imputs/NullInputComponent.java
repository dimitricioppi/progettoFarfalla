/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package progettofarfalla.Model.Imputs;

/**
 *
 * @author Daniela
 */

import progettofarfalla.Model.Imputs.InputComponent;
import progettofarfalla.Model.Game.GameObjects.GameObject;

public class NullInputComponent implements InputComponent {

    @Override
    public void update(GameObject obj){

    }

}
