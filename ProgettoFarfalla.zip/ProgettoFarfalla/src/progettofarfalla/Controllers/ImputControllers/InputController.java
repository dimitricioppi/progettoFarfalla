/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package progettofarfalla.Controllers.ImputControllers;

/**
 *
 * @author Daniela
 */
public interface InputController {

    boolean isMoveUp();	
    boolean isMoveDown();	
    boolean isMoveLeft();	
    boolean isMoveRight();
    boolean isNull();

}
